package com.ardy.ardysubmisfunda

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class Adapterg (val listLatih: ArrayList<Github>) : RecyclerView.Adapter<Adapterg.ListViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var username: TextView = itemView.findViewById(R.id.tv_item_name)
        var location: TextView = itemView.findViewById(R.id.tv_item_location)
        var office: TextView = itemView.findViewById(R.id.tv_item_kerja)
        var imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ListViewHolder {
        val view: View = LayoutInflater.from(viewGroup.context).inflate(R.layout.github_list, viewGroup, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val gith = listLatih[position]
        Glide.with(holder.itemView.context)
            .load(gith.photo)
            .apply(RequestOptions().override(1000, 1000))
            .into(holder.imgPhoto)
        holder.username.text = gith.username
        holder.location.text = gith.location
        holder.office.text = gith.company
        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(listLatih[holder.adapterPosition]) }
    }

    override fun getItemCount(): Int {
        return listLatih.size
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: Github)
    }
}