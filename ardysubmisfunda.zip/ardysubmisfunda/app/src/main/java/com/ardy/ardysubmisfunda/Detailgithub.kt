package com.ardy.ardysubmisfunda

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import de.hdodenhof.circleimageview.CircleImageView
import java.io.File
import java.io.FileOutputStream

class Detailgithub : AppCompatActivity() {

    companion object {

        const val EXTRA_NAME = "extra_name"

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        supportActionBar?.title = "Detail Profile"
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailgithub)
        val Name: TextView = findViewById(R.id.txt_nama_github)
        val username: TextView = findViewById(R.id.txt_username)
        val location : TextView = findViewById(R.id.txt_location)
        val company: TextView = findViewById(R.id.txt_kerja)
        val repo: TextView = findViewById(R.id.txt_repo)
        val following: TextView = findViewById(R.id.isi_following)
        val followers: TextView = findViewById(R.id.isi_followers)
        val followerstulis: TextView = findViewById(R.id.txt_followers)
        val followingtulis: TextView = findViewById(R.id.txt_following)
        val imageView: CircleImageView = findViewById(R.id.profile_image)
        val repos: TextView = findViewById(R.id.txt_repos)

        val item = intent.getParcelableExtra(EXTRA_NAME)  as Github
        Name.text = item.name
        username.text = "("+"@" + item.username+")"
        location.text = item.location
        company.text = item.company
        repo.text = item.repository
        following.text = item.following
        followers.text = item.followers
        followerstulis.text = "Followers"
        followingtulis.text = "Following"
        repos.text = "Repositories :"
        imageView.setImageResource(item.photo)


        val btnShare : Button = findViewById(R.id.btn_share)
        val builder: StrictMode.VmPolicy.Builder = StrictMode.VmPolicy.Builder()
        StrictMode.setVmPolicy(builder.build())
        val post_image = findViewById<View>(R.id.profile_image) as ImageView
        val myDrawable = post_image.drawable
        val bitmap = (myDrawable as BitmapDrawable).bitmap
        btnShare.setOnClickListener {





//            val intentZ = Intent()
//            intentZ.action = Intent.ACTION_SEND
//            intentZ.putExtra(Intent.EXTRA_TEXT, message)
//            intentZ.type = "text/plain"
//            startActivity(Intent.createChooser(intentZ, "Share To:"))


            try {
                val message: String =  "Follow   " + item.username +"   On Github!!!"
                val file = File(externalCacheDir, "ardy.png")
                val fOut = FileOutputStream(file)
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut)
                fOut.flush()
                fOut.close()
                file.setReadable(true, false)
                val intent = Intent(android.content.Intent.ACTION_SEND)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file))
                intent.type = "image/png"
                intent.putExtra(Intent.EXTRA_TEXT, message)
                intent.type = "text/plain"
                startActivity(Intent.createChooser(intent, "Share image via"))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        var actionBar = getSupportActionBar()

        // showing the back button in action bar
        if (actionBar != null) {


            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        return super.onCreateOptionsMenu(menu)


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        setMode(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setMode(selectedMode: Int) {
        when (selectedMode) {
            android.R.id.home  -> {
                Findah()

            }

        }
    }


    private fun Findah() {

        val move =  Intent (this@Detailgithub, MainActivity::class.java)
        move.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        move.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
        move.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        move.putExtra("EXIT", true)

        startActivity(move)
        finish()


    }
}